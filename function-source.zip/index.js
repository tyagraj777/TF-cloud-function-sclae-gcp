exports.helloWorld = (req, res) => {
  res.status(200).send('Hello, World! This is a scalable Cloud Function.');
};

